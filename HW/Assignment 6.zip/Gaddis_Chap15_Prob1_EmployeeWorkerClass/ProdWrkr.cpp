/* 
 * File:   ProdWrkr.cpp
 * Author: Jose Temblador
 *
 * Created on July 26, 2021, 8:03 PM
 */

#include "ProdWrkr.h"
#include <cstdlib>

using namespace std;


void ProdWrkr::setShift(int s) {
    shift=s;
}

void ProdWrkr::setRate(float r) {
    rate=r;
}