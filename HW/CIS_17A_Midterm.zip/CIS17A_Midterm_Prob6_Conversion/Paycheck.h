/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Paycheck.h
 * Author: mac
 *
 * Created on July 16, 2021, 3:33 AM
 */

#ifndef PAYCHECK_H
#define PAYCHECK_H

struct PayCheck {
    string name;     //employee name
    string add;
    float hrs;         //hours worked 
    float pay;       //gross pay
};

#endif /* PAYCHECK_H */

