/* 
 * File:   Hello_World.cpp
 * Author: Jose Temblador
 * Created on June 24, 2021, 6:58 PM
 * Purpose:  Hello World program
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Seed the random number function
    
    //Declare Variables
    
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    cout<<"Hello World!";
    //Exit stage right!
    return 0;
}